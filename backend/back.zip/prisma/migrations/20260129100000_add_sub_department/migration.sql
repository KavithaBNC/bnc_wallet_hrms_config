-- CreateTable
CREATE TABLE "sub_departments" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "organization_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sub_departments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "sub_departments_organization_id_name_key" ON "sub_departments"("organization_id", "name");

-- AddForeignKey
ALTER TABLE "sub_departments" ADD CONSTRAINT "sub_departments_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AlterTable: add sub_department_id to employees
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "sub_department_id" UUID;

-- AddForeignKey
ALTER TABLE "employees" ADD CONSTRAINT "employees_sub_department_id_fkey" FOREIGN KEY ("sub_department_id") REFERENCES "sub_departments"("id") ON DELETE SET NULL ON UPDATE CASCADE;
