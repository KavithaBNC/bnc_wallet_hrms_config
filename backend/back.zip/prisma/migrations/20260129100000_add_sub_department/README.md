# Sub-Department Migration

## Fix "column employees.sub_department_id does not exist"

1. **Regenerate Prisma client** (so it matches the current schema; Employee no longer has `sub_department_id` until you add the column):
   ```bash
   cd backend
   npx prisma generate
   ```
2. **Restart the backend**: stop with Ctrl+C, then `npm run dev`.

The Employee list will load. The schema currently does not include `sub_department_id` on Employee so it works with your existing DB.

## Optional: Add sub_departments table and one department + subdepartment

1. **Run the migration** (no psql needed; uses Node + Prisma and your `.env` DATABASE_URL):
   ```bash
   npm run migrate:sub-department
   ```
   This creates the `sub_departments` table and adds `sub_department_id` to `employees`.

   *Alternative:* If you have psql installed: `psql "%DATABASE_URL%" -f prisma/migrations/20260129100000_add_sub_department/run-first.sql`  
   Or run `run-first.sql` manually in pgAdmin / any PostgreSQL client.

2. **Seed one department and one subdepartment**:
   ```bash
   npm run seed:dept-subdept
   ```
   Or run the full seed: `npm run prisma:seed` (adds HR Operations sub-department if the table exists).
