-- Run this SQL in your PostgreSQL client (e.g. psql, pgAdmin, or: psql $DATABASE_URL -f run-first.sql)
-- to create sub_departments table and add sub_department_id to employees.
-- Idempotent: safe to run multiple times.

-- 1. Create sub_departments table
CREATE TABLE IF NOT EXISTS "sub_departments" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "organization_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "sub_departments_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "sub_departments_organization_id_name_key"
ON "sub_departments"("organization_id", "name");

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'sub_departments_organization_id_fkey'
    ) THEN
        ALTER TABLE "sub_departments"
        ADD CONSTRAINT "sub_departments_organization_id_fkey"
        FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
END $$;

-- 2. Add sub_department_id to employees (optional - only if you want to link employees to sub-departments)
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "sub_department_id" UUID;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'employees_sub_department_id_fkey'
    ) THEN
        ALTER TABLE "employees"
        ADD CONSTRAINT "employees_sub_department_id_fkey"
        FOREIGN KEY ("sub_department_id") REFERENCES "sub_departments"("id") ON DELETE SET NULL ON UPDATE CASCADE;
    END IF;
END $$;
